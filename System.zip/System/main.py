
import discord
from discord.ext import commands
import os

# Configure bot intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Initialize bot with command prefix '!'
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Bot is logged in as {bot.user}')

@bot.command()
async def hello(ctx):
    await ctx.send(f'Hello {ctx.author.name}!')

@bot.command()
async def ping(ctx):
    await ctx.send(f'Pong! Latency: {round(bot.latency * 1000)}ms')

# Get token from environment variable
bot.run(os.getenv('DISCORD_TOKEN'))
