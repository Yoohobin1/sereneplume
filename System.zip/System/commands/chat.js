
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('chat')
    .setDescription('Chat with the bot')
    .addStringOption(option =>
      option
        .setName('message')
        .setDescription('The message you want to send to the bot')
        .setRequired(true)
    ),

  async execute(prodia, interaction) {
    const message = interaction.options.getString('message');
    
    // Simple response logic - you can enhance this with more complex responses
    let response = "I'm a simple chatbot. You said: " + message;
    
    // Basic personality responses
    if (message.toLowerCase().includes('hello') || message.toLowerCase().includes('hi')) {
      response = `Hello ${interaction.user.username}! How can I help you today?`;
    } else if (message.toLowerCase().includes('how are you')) {
      response = "I'm doing great, thanks for asking! How about you?";
    }

    await interaction.reply({
      content: response,
      ephemeral: false
    });
  }
};
